// constants.ts - DMmasmMenu
