// constants.ts - DMmasmBadCode
