// constants.ts - DPmasmProcess
